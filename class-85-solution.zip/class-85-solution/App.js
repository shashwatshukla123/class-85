import * as React from 'react';
import { createSwitchNavigator,createAppContainer } from 'react-navigation';
import LoginScreen from './screens/LoginScreen';
import LoadingScreen from './screens/LoadingScreen';
import DashboardScreen from './screens/DashboardScreen';

export default function App(){
  return(
    <AppNavigator/>
  )
}

const AppSwitchnavigator= createSwitchNavigator({
  LoadingScreen:LoadingScreen,
  LoginScreen:LoginScreen,
  DashboardScreen:DashboardScreen,
})

const AppNavigator=createAppContainer(AppSwitchnavigator)